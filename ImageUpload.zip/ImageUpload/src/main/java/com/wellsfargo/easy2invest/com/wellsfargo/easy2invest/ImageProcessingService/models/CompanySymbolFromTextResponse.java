package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.models;

import java.util.List;

public class CompanySymbolFromTextResponse {

	private List<String> companySymbols;
	private ErrorResponse error;

	public List<String> getCompanySymbols() {
		return companySymbols;
	}

	public void setCompanySymbols(List<String> companySymbols) {
		this.companySymbols = companySymbols;
	}

	public ErrorResponse getError() {
		return error;
	}

	public void setError(ErrorResponse error) {
		this.error = error;
	}

	@Override
	public String toString() {
		return "CompanySymbolFromTextResponse [companySymbols=" + companySymbols + ", error=" + error + "]";
	}

}

