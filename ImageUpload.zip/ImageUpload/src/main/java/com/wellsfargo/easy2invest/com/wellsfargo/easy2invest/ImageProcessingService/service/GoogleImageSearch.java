package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.service;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import com.google.cloud.vision.v1.*;
import com.google.protobuf.ByteString;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

import java.io.IOException;

public class GoogleImageSearch {

    public static void searchByImage() {
        try {
        	String imageUrl = "E:\\LearningDirectory\\Image_Processing\\Images\\Hyundai.jpg";
//            String googleSearchUrl = "https://www.google.com/searchbyimage?image_url=" + imageUrl;
        	String googleSearchUrl = "https://www.google.com/searchbyimage?image_url=" + URLEncoder.encode(imageUrl, "UTF-8");
        	System.out.println("googleSearchUrl : "+googleSearchUrl);
            Document document = Jsoup.connect(googleSearchUrl).get();
            System.out.println("1");
            Elements results = document.select("h3.r > a");
            System.out.println("2");
            System.out.println(results.size());
            for (Element result : results) {
                String title = result.text();
                String link = result.attr("href");
                System.out.println("Title: " + title);
                System.out.println("Link: " + link);
                System.out.println("-----");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    public static void GoogleCloudVisionAPI() throws Exception {
        String imagePath = "E:\\LearningDirectory\\Image_Processing\\Images\\Hyundai.jpg";  // Replace with the actual path to your image

        ImageAnnotatorClient vision = ImageAnnotatorClient.create();

        Path path = Paths.get(imagePath);
        byte[] data = Files.readAllBytes(path);
        ByteString imgBytes = ByteString.copyFrom(data);

        Image img = Image.newBuilder().setContent(imgBytes).build();
        Feature feat = Feature.newBuilder().setType(Feature.Type.LABEL_DETECTION).build();
        AnnotateImageRequest request = AnnotateImageRequest.newBuilder()
                .addFeatures(feat)
                .setImage(img)
                .build();

        BatchAnnotateImagesResponse response = vision.batchAnnotateImages(List.of(request));
        vision.close();

        for (AnnotateImageResponse res : response.getResponsesList()) {
            for (EntityAnnotation annotation : res.getLabelAnnotationsList()) {
                System.out.println("Label: " + annotation.getDescription());
                System.out.println("Score: " + annotation.getScore());
            }
        }
    }
}
