package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.utility;

import org.springframework.stereotype.Component;
import java.text.SimpleDateFormat;
import java.util.Date;
@Component
public class Utility {

	public static String generateFileNameWithTimestamp(String fileName) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        String timestamp = dateFormat.format(new Date());
        return timestamp + "_" + fileName;
    }
}
