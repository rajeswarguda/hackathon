package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.models.CompanySymbolFromTextResponse;

@Component
public class CompanySymbolService {

	@Autowired
	private RestTemplate restTemplate;

	public List<String> getCompanySymbols(String text) {

		String url = "http://localhost:8081/api/companysymbolfromtext?text=" + text;
		ResponseEntity<CompanySymbolFromTextResponse> response = restTemplate.getForEntity(url,
				CompanySymbolFromTextResponse.class);

		return response.getBody().getCompanySymbols();

	}

}
