package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.CollectionUtils;
import org.springframework.web.multipart.MultipartFile;

import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.models.ErrorResponse;
import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.models.ImageToTextResponse;
import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.utility.Utility;

@Component
public class GetCompanyTickerSymbolService {
	
	@Value("${upload.dir}")
    private String uploadDir;
	
	@Autowired
    private Utility utility;
	
	@Autowired
	private CompanySymbolService companySymbolService;

	public ResponseEntity<ImageToTextResponse> uploadImageAndGetCompanyTickerSymbol(MultipartFile file) {
		ImageToTextResponse imageToTextResponse = new ImageToTextResponse();
		File directory = new File(uploadDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        String fileName = file.getOriginalFilename();
        String fileNameWithTimestamp = utility.generateFileNameWithTimestamp(fileName);
        System.out.println("fileNameWithTimestamp : "+fileNameWithTimestamp);
        String filePath = uploadDir + File.separator + fileNameWithTimestamp;
        System.out.println("filePath : "+filePath);
        try {
            file.transferTo(new File(filePath));
            String text = ImageToTextConverterService.imageToTextByFile(filePath);
            System.out.println("text : "+text);
            List<String> companyNames = companySymbolService.getCompanySymbols(text);
            if (CollectionUtils.isEmpty(companyNames)) {
            	imageToTextResponse.setError(new ErrorResponse("001", "Warning", "No Data Found"));
    			return new ResponseEntity<>(imageToTextResponse, HttpStatus.OK);
    		}else {
    			imageToTextResponse.setCompanyTickerSymbol(companyNames.get(0));
                System.out.println("imageToTextResponse : "+imageToTextResponse);
                return new ResponseEntity<>(imageToTextResponse, HttpStatus.OK);
    		}
            
        } catch (IOException e) {
        	e.printStackTrace();
        	imageToTextResponse.setError(new ErrorResponse("001", "Warning", "No Data Found"));
        	return new ResponseEntity<>(imageToTextResponse, HttpStatus.OK);
        }
	}
	
	public ResponseEntity<ImageToTextResponse> getCompanyTickerSymbolFromLogo(MultipartFile file) {
		ImageToTextResponse imageToTextResponse = new ImageToTextResponse();
        System.out.println("FileName without Extension : "+removeFileExtension(file.getOriginalFilename()));
            List<String> companyNames = companySymbolService.getCompanySymbols(removeFileExtension(file.getOriginalFilename()));
            if (CollectionUtils.isEmpty(companyNames)) {
            	imageToTextResponse.setError(new ErrorResponse("001", "Warning", "No Data Found"));
    			return new ResponseEntity<>(imageToTextResponse, HttpStatus.OK);
    		}else {
    			imageToTextResponse.setCompanyTickerSymbol(companyNames.get(0));
                System.out.println("imageToTextResponse : "+imageToTextResponse);
                return new ResponseEntity<>(imageToTextResponse, HttpStatus.OK);
    		}
            
	}
	
	public ResponseEntity<ImageToTextResponse> getCompanyTickerSymbolFromText(String text) {
		ImageToTextResponse imageToTextResponse = new ImageToTextResponse();
            List<String> companyNames = companySymbolService.getCompanySymbols(text);
            if (CollectionUtils.isEmpty(companyNames)) {
            	imageToTextResponse.setError(new ErrorResponse("001", "Warning", "No Data Found"));
    			return new ResponseEntity<>(imageToTextResponse, HttpStatus.OK);
    		}else {
    			imageToTextResponse.setCompanyTickerSymbol(companyNames.get(0));
                System.out.println("imageToTextResponse : "+imageToTextResponse);
                return new ResponseEntity<>(imageToTextResponse, HttpStatus.OK);
    		}
	}
	
	private static String removeFileExtension(String fileName) {
        int lastIndexOfDot = fileName.lastIndexOf('.');
        if (lastIndexOfDot == -1) {
            return fileName;
        } else {
            return fileName.substring(0, lastIndexOfDot);
        }
    }
}
