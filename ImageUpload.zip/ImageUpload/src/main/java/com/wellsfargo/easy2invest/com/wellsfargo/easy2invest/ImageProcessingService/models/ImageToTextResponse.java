package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.models;


public class ImageToTextResponse {

	private String companyTickerSymbol;
	private ErrorResponse error;
	public String getCompanyTickerSymbol() {
		return companyTickerSymbol;
	}
	public void setCompanyTickerSymbol(String companyTickerSymbol) {
		this.companyTickerSymbol = companyTickerSymbol;
	}
	public ErrorResponse getError() {
		return error;
	}
	public void setError(ErrorResponse error) {
		this.error = error;
	}
	@Override
	public String toString() {
		return "ImageToTextResponse [companyTickerSymbol=" + companyTickerSymbol + ", error=" + error + "]";
	}
	
}
