package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.controller;

import java.io.File;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.models.ImageToTextResponse;
import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.service.GetCompanyTickerSymbolService;
import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.service.GoogleImageSearch;
import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.service.ImageToTextConverterService;
import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.utility.Utility;

@RestController
public class ImageToNameConverterController {

	@Autowired
	private GetCompanyTickerSymbolService getCompanyTickerSymbolService;

	@PostMapping("/api/getCompanyNameFromImage")
	public ResponseEntity<ImageToTextResponse> handleFileUpload(@RequestParam("file") MultipartFile file) {

		return getCompanyTickerSymbolService.uploadImageAndGetCompanyTickerSymbol(file);

	}
	
	@PostMapping("/api/getCompanyNameFromLogo")
	public ResponseEntity<ImageToTextResponse> handleFileUploadForLogo(@RequestParam("file") MultipartFile file) {

		return getCompanyTickerSymbolService.getCompanyTickerSymbolFromLogo(file);

	}
	
	@GetMapping("/api/getCompanyNameFromText")
	public ResponseEntity<ImageToTextResponse> getCompanyTickerSymbol(@RequestParam String text) {

		return getCompanyTickerSymbolService.getCompanyTickerSymbolFromText(text);

	}

	@GetMapping("/LogoToName")
	public void LogoToName() throws Exception {
		System.out.println("Inside the LogoToName");
//        GoogleImageSearch.searchByImage();
		GoogleImageSearch.GoogleCloudVisionAPI();
	}

	@GetMapping("/ImageToText")
	public void ImageToText() {
		System.out.println("Inside the ImageToText");
		ImageToTextConverterService.imageToText();
	}
}
