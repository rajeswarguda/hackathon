package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.ImageProcessingService.service;

import java.io.File;

import net.sourceforge.tess4j.Tesseract;
import net.sourceforge.tess4j.TesseractException;

public class ImageToTextConverterService {

	public static void imageToText() {
		Tesseract tesseract = new Tesseract(); 
		try { 

			tesseract.setDatapath("E:\\LearningDirectory\\Image_Processing\\Tess4J\\tessdata");  
			String text = tesseract.doOCR(new File("E:\\\\LearningDirectory\\\\Image_Processing\\\\Images\\\\Hyundai.jpg")); 
			
//			String text = tesseract.doOCR(new File("E:\\LearningDirectory\\Image_Processing\\Images\\wellsfargo.jpg"));

			System.out.print(text); 
		} 
		catch (TesseractException e) { 
			e.printStackTrace(); 
		}
	}
	
	public static String imageToTextByFile(String filepath) {
		Tesseract tesseract = new Tesseract(); 
		try { 
			tesseract.setDatapath("E:\\LearningDirectory\\Image_Processing\\Tess4J\\tessdata");  
			return tesseract.doOCR(new File(filepath)); 
		} 
		catch (TesseractException e) { 
			e.printStackTrace(); 
			return "Unable to read";
		}
	}
}
