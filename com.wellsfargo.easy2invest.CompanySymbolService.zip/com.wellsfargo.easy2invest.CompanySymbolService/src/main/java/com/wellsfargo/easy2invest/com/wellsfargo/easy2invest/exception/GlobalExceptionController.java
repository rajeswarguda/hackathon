package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.models.CompanySymbolFromTextResponse;
import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.models.ErrorResponse;

@ControllerAdvice
public class GlobalExceptionController {

	@ExceptionHandler(value = Exception.class)
	public ResponseEntity<CompanySymbolFromTextResponse> exception(Exception exception) {

		CompanySymbolFromTextResponse CompanySymbolFromTextResponse = new CompanySymbolFromTextResponse();

		CompanySymbolFromTextResponse
				.setError(new ErrorResponse("002", "Error", "Critical Error" + exception.getMessage()));

		return new ResponseEntity<>(CompanySymbolFromTextResponse, HttpStatus.SERVICE_UNAVAILABLE);
	}
}