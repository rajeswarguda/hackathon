package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.CompanySymbolService.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONObject;
import org.springframework.stereotype.Component;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@Component
public class CompanySymbolRetrieverService2 {

	private static final String API_KEY = "XWVKRYHV7OQQPP8U";
	private static final String BASE_URL = "https://www.alphavantage.co/query";

	public List<String> getCompanySymbolFromText(String companyName) {
		List<String> symbolList = null;
		try {
			symbolList = getCompanySymbol(companyName);
		} catch (IOException e) {
			System.err.println("An error occurred: " + e.getMessage());
		}
		return symbolList;
	}

	public static List<String> getCompanySymbol(String companyName) throws IOException {
		OkHttpClient client = new OkHttpClient();
        String function = "SYMBOL_SEARCH";
        String apiKey = "apikey=" + API_KEY;
        String keywords = "keywords=" + companyName;

        String url = String.format("%s?function=%s&%s&%s", BASE_URL, function, apiKey, keywords);

        Request request = new Request.Builder()
                .url(url)
                .build();

		try (Response response = client.newCall(request).execute()) {
			if (!response.isSuccessful())
				throw new IOException("Unexpected code " + response);

			String responseBody = response.body().string();
			
			JSONObject jo = new JSONObject(responseBody);
			JSONArray jsonArray = jo.getJSONArray("bestMatches");
			
			List<String> locations = new ArrayList<>();
			for (int i = 0; i < jsonArray.length(); i++) {
				locations.add(jsonArray.getJSONObject(i).getString("1. symbol"));
				  }
			
			return locations;
		}
	}
}