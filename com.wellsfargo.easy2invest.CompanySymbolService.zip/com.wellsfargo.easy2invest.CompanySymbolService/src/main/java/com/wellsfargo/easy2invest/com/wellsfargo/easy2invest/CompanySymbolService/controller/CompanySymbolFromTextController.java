package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.CompanySymbolService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.CompanySymbolService.service.CompanySymbolRetrieverService;
import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.CompanySymbolService.service.CompanySymbolRetrieverService2;
import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.models.CompanySymbolFromTextResponse;
import com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.models.ErrorResponse;

@RestController
public class CompanySymbolFromTextController {

	@Autowired
	private CompanySymbolRetrieverService companySymbolRetrieverService;

	@GetMapping("/api/companysymbolfromtext")
	public ResponseEntity<CompanySymbolFromTextResponse> getCompanySymbolFromText(@RequestParam String text) {

		CompanySymbolFromTextResponse CompanySymbolFromTextResponse = new CompanySymbolFromTextResponse();
		
		List<String> companySymbolFromText = companySymbolRetrieverService.getCompanySymbolFromText(text);
		
		if (CollectionUtils.isEmpty(companySymbolFromText)) {
			CompanySymbolFromTextResponse.setError(new ErrorResponse("001", "Warning", "No Data Found"));
			return new ResponseEntity<>(CompanySymbolFromTextResponse, HttpStatus.OK);
		}
		CompanySymbolFromTextResponse.setCompanySymbols(companySymbolFromText);
		return new ResponseEntity<>(CompanySymbolFromTextResponse, HttpStatus.OK);
	}

}
