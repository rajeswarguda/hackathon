package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.models;

public class CompanySymbolFromTextResponse {

	private String companySymbol;
	private ErrorResponse error;

	public String getCompanySymbol() {
		return companySymbol;
	}

	public void setCompanySymbol(String companySymbol) {
		this.companySymbol = companySymbol;
	}

	public ErrorResponse getError() {
		return error;
	}

	public void setError(ErrorResponse error) {
		this.error = error;
	}

	@Override
	public String toString() {
		return "CompanySymbolFromTextResponse [companySymbol=" + companySymbol + ", error=" + error + "]";
	}

}
