package com.wellsfargo.easy2invest.com.wellsfargo.easy2invest.CompanySymbolService.service;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Component;

import com.jayway.jsonpath.Criteria;
import com.jayway.jsonpath.Filter;
import com.jayway.jsonpath.JsonPath;

import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

@Component
public class CompanySymbolRetrieverService {

	private static final String API_KEY = "FHETJoZ5BYm9hH6Dyp4vlLJz0lF1pbye";
	private static final String BASE_URL = "https://financialmodelingprep.com/api/v3/search";

	public List<String> getCompanySymbolFromText(String companyName) {
		List<String> symbolList = null;
		try {
			symbolList = getCompanySymbol(companyName);
		} catch (IOException e) {
			System.err.println("An error occurred: " + e.getMessage());
		}
		return symbolList;
	}

	public static List<String> getCompanySymbol(String companyName) throws IOException {
		OkHttpClient client = new OkHttpClient();
		String apiKey = "apikey=" + API_KEY;
		String query = "query=" + companyName;

		String url = String.format("%s?%s&%s", BASE_URL, query, apiKey);

		Request request = new Request.Builder().url(url).build();

		try (Response response = client.newCall(request).execute()) {
			if (!response.isSuccessful())
				throw new IOException("Unexpected code " + response);

			String responseBody = response.body().string();
			
			List<String> locations = JsonPath.read(responseBody, ".[?(@['exchangeShortName'] == 'NASDAQ')].symbol");
			
			if(locations.size()>0)
				locations = Arrays.asList(locations.get(0));

			return locations;
		}
	}
}