
Softwares
----------

1. Spring Tool Suite 4 https://spring.io/tools
2. Java 11 https://www.oracle.com/in/java/technologies/javase/jdk11-archive-downloads.html#license-lightbox
 